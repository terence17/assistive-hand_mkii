import React from "react";
import MW27 from "../components/Results/CurrentMwPred"; 

const Predictions = () => {
  return (
    <div>
      <h1>Upcoming Match Predictions</h1>
      <MW27 /> 
    </div>
  );
};

export default Predictions;